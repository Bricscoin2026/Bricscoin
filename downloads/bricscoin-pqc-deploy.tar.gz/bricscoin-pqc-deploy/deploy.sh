#!/bin/bash
# =============================================================================
# BricsCoin PQC Deploy Script v2.1
# Deploy completo: Backend (PQC) + Frontend aggiornato
# Usa "docker compose" (v2)
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "========================================"
echo "  BricsCoin PQC Deploy v2.1"
echo "  $(date)"
echo "========================================"

# Detect project directory
BRICS_DIR=""
for dir in /root/bricscoin /root/BricsCoin /root/bricscoin26; do
    if [ -d "$dir/backend" ]; then
        BRICS_DIR="$dir"
        break
    fi
done

if [ -z "$BRICS_DIR" ]; then
    echo "ERRORE: Directory del progetto non trovata!"
    exit 1
fi

echo "Directory progetto: $BRICS_DIR"

# ==================== STEP 1: BACKUP ====================
echo ""
echo "[1/6] Backup dei file attuali..."
BACKUP_DIR="/root/bricscoin-backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR/backend" "$BACKUP_DIR/frontend"
cp "$BRICS_DIR/backend/server.py" "$BACKUP_DIR/backend/" 2>/dev/null || true
cp "$BRICS_DIR/backend/stratum_server.py" "$BACKUP_DIR/backend/" 2>/dev/null || true
cp "$BRICS_DIR/backend/requirements.txt" "$BACKUP_DIR/backend/" 2>/dev/null || true
cp "$BRICS_DIR/Dockerfile" "$BACKUP_DIR/" 2>/dev/null || true
cp "$BRICS_DIR/frontend/Dockerfile.frontend" "$BACKUP_DIR/frontend/" 2>/dev/null || true
echo "  Backup: $BACKUP_DIR"

# ==================== STEP 2: COPY FILES ====================
echo ""
echo "[2/6] Copia file aggiornati..."

# Backend
cp "$SCRIPT_DIR/backend/pqc_crypto.py" "$BRICS_DIR/backend/"
cp "$SCRIPT_DIR/backend/server.py" "$BRICS_DIR/backend/"
cp "$SCRIPT_DIR/backend/stratum_server.py" "$BRICS_DIR/backend/"
cp "$SCRIPT_DIR/backend/requirements.txt" "$BRICS_DIR/backend/"
echo "  Backend: server.py, pqc_crypto.py, stratum_server.py, requirements.txt"

# Dockerfile (backend)
cp "$SCRIPT_DIR/Dockerfile" "$BRICS_DIR/"
echo "  Dockerfile API aggiornato"

# Frontend - copy entire src directory
mkdir -p "$BRICS_DIR/frontend/src/pages" "$BRICS_DIR/frontend/src/lib" "$BRICS_DIR/frontend/src/components/ui"
cp "$SCRIPT_DIR/frontend/src/App.js" "$BRICS_DIR/frontend/src/"
cp "$SCRIPT_DIR/frontend/src/App.css" "$BRICS_DIR/frontend/src/"
cp "$SCRIPT_DIR/frontend/src/index.js" "$BRICS_DIR/frontend/src/"
cp "$SCRIPT_DIR/frontend/src/index.css" "$BRICS_DIR/frontend/src/"
cp "$SCRIPT_DIR/frontend/src/pages/"*.jsx "$BRICS_DIR/frontend/src/pages/"
cp "$SCRIPT_DIR/frontend/src/lib/"*.js "$BRICS_DIR/frontend/src/lib/"
cp "$SCRIPT_DIR/frontend/src/components/Layout.jsx" "$BRICS_DIR/frontend/src/components/"
cp "$SCRIPT_DIR/frontend/src/components/ui/"* "$BRICS_DIR/frontend/src/components/ui/" 2>/dev/null || true
cp "$SCRIPT_DIR/frontend/package.json" "$BRICS_DIR/frontend/"
cp "$SCRIPT_DIR/frontend/yarn.lock" "$BRICS_DIR/frontend/"
cp "$SCRIPT_DIR/frontend/Dockerfile.frontend" "$BRICS_DIR/frontend/"
cp "$SCRIPT_DIR/frontend/nginx-frontend.conf" "$BRICS_DIR/frontend/" 2>/dev/null || true
cp "$SCRIPT_DIR/frontend/tailwind.config.js" "$BRICS_DIR/frontend/" 2>/dev/null || true
cp "$SCRIPT_DIR/frontend/craco.config.js" "$BRICS_DIR/frontend/" 2>/dev/null || true
cp "$SCRIPT_DIR/frontend/postcss.config.js" "$BRICS_DIR/frontend/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/frontend/public" "$BRICS_DIR/frontend/" 2>/dev/null || true
echo "  Frontend: TUTTE le pagine, componenti, lib, config"

# ==================== STEP 3: DISK CLEANUP CRON ====================
echo ""
echo "[3/6] Pulizia disco cron..."

cat > "$BRICS_DIR/disk-cleanup.sh" << 'CLEANEOF'
#!/bin/bash
echo "=== BricsCoin Disk Cleanup - $(date) ==="
docker system prune -af --volumes 2>/dev/null || true
journalctl --vacuum-size=100M 2>/dev/null || true
find /var/log -name "*.log.*" -mtime +14 -delete 2>/dev/null || true
find /var/log -name "*.gz" -mtime +14 -delete 2>/dev/null || true
find /tmp -type f -mtime +7 -delete 2>/dev/null || true
pip cache purge 2>/dev/null || true
df -h / | tail -1
echo "=== Cleanup complete ==="
CLEANEOF
chmod +x "$BRICS_DIR/disk-cleanup.sh"
(crontab -l 2>/dev/null | grep -v "disk-cleanup.sh"; echo "0 3 * * 0 $BRICS_DIR/disk-cleanup.sh >> /var/log/bricscoin-cleanup.log 2>&1") | crontab -
echo "  Cron installato (Domenica 3:00)"

# ==================== STEP 4: REBUILD CONTAINERS ====================
echo ""
echo "[4/6] Ricostruzione container Docker..."
cd "$BRICS_DIR"

# Detect compose file
COMPOSE_FILE=""
if [ -f "docker-compose.prod.yml" ]; then
    COMPOSE_FILE="-f docker-compose.prod.yml"
elif [ -f "docker-compose.yml" ]; then
    COMPOSE_FILE=""
fi

echo "  Building API..."
docker compose $COMPOSE_FILE build bricscoin-api 2>&1 | tail -5

echo "  Building Frontend..."
docker compose $COMPOSE_FILE build bricscoin-frontend 2>&1 | tail -5

echo "  Building Stratum..."
docker compose $COMPOSE_FILE build bricscoin-stratum 2>&1 | tail -5 || echo "  (Stratum build skipped)"

# ==================== STEP 5: RESTART SERVICES ====================
echo ""
echo "[5/6] Riavvio servizi (MongoDB NON toccato)..."

docker compose $COMPOSE_FILE up -d --no-deps bricscoin-api
docker compose $COMPOSE_FILE up -d --no-deps bricscoin-frontend
docker compose $COMPOSE_FILE up -d --no-deps bricscoin-stratum 2>/dev/null || true

echo "  Servizi riavviati"
docker compose $COMPOSE_FILE ps

# ==================== STEP 6: VERIFY ====================
echo ""
echo "[6/6] Verifica (attendo 15s per startup)..."
sleep 15

echo "  Test API base..."
curl -s http://localhost:8001/api/ 2>/dev/null | head -1
echo ""

echo "  Test PQC Stats..."
curl -s http://localhost:8001/api/pqc/stats 2>/dev/null
echo ""

echo "  Test PQC Node Keys..."
curl -s http://localhost:8001/api/pqc/node/keys 2>/dev/null | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'Node: {d[\"node_id\"]}, Scheme: {d[\"scheme\"]}')" 2>/dev/null || echo "  (in attesa di startup...)"

echo "  Test PQC Wallet Create..."
curl -s -X POST http://localhost:8001/api/pqc/wallet/create -H "Content-Type: application/json" -d '{"name":"deploy-test"}' 2>/dev/null | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'Wallet: {d[\"address\"]}')" 2>/dev/null || echo "  (in attesa di startup...)"

echo ""
echo "========================================"
echo "  DEPLOY COMPLETATO!"
echo "  Backup: $BACKUP_DIR"
echo "  Blockchain: INTATTA"
echo ""
echo "  Verifica: https://bricscoin26.org/pqc-wallet"
echo "========================================"
